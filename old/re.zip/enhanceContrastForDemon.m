function frameOut = enhanceContrastForDemon(inputFrame)  
          
   frameIn=inputFrame;
            
%             frameIn=trackMov(:,:,qq);
            frameInA = imadjust(frameIn);

            frameIn = wiener2(frameInA,[10 10]);
%             frameIn = imhistmatch(frameIn,refContrast);
            background = imopen(frameIn,strel('disk',15));
%             H = fspecial('disk',60);
%             background = imfilter(background,H,'replicate');
            frameIn = frameInA - background;
            frameIn = imadjust(frameIn);
            frameIn = wiener2(frameIn,[10 10]);
            frameOut=frameIn;
%             imshow(frameOut)
    
end