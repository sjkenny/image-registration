% here’s the basic demon registration code and how to use it with parfor loops - the “affineMov” variable is the movie to be %registered.

demonMovies = cell(nNmjs,1);
dispFields = cell(nNmjs,1);

parfor nmjNum = 1:nNmjs   
    affineMov = affineStore{nmjNum};
        disp(['Starting Demon NMJ #: ',num2str(nmjNum)])

        refFrameNorm = affineMov(:,:,maxFrameNum);
        refFrame = enhanceContrastForDemon(refFrameNorm);

        demonDispFields = cell(nFrames,1);
        demon=zeros(size(refFrame,1),size(refFrame,2),nFrames,'uint16');

        for qq = 1:nFrames
            frameNorm = affineMov(:,:,qq);
            movingFrame=enhanceContrastForDemon(frameNorm);
            [dField,~] = imregdemons(movingFrame,refFrame,[400 200 100],...
                'PyramidLevels',3,'AccumulatedFieldSmoothing',1);
            movingRegistered = imwarp(frameNorm,dField);  
%             imshow(movingFrame,[]);drawnow;refresh;
            demonDispFields{qq,1}=dField;
            demon(:,:,qq)=(movingRegistered);
            disp(['NMJ #: ',num2str(nmjNum),' Frame #: ',num2str(qq)]);   
  
        end
        
        demonMovies{nmjNum,1}=demon;
        dispFields{nmjNum,1}=demonDispFields;     
end
 
 
for demonMovieNum = 1:nNmjs   
    demon=demonMovies{demonMovieNum,1};
    demonDispFields=dispFields{demonMovieNum,1};
    FileNameApp = affinedFileNames(demonMovieNum).name;
    save(FileNameApp,'demonDispFields','demon','-append')
    clear demon demonDispFields
end        
    
    


toc
% catch
% end


% cd(moviesToRegisterDirectory)
end

